import{a as t}from"../chunks/entry.DQvxNPFL.js";export{t as start};
